const checkForm = document.querySelector('#btnCheck')
const voornaam = document.querySelector('#voornaam')
const naam = document.querySelector('#naam')
let errors = []
checkBetaling('app', 'overschrijving','visa','paypal')
hideAlerts()

checkForm.addEventListener('click', checkFormulier)
checkForm.addEventListener('click', checkBetaling)
checkForm.addEventListener('click',checkVoorwaarden)

function checkFormulier() {
    errors = []
    checkEmptyField('voornaam', 'Het veld voornaam is vereist.')
    checkEmptyField('naam', 'Het veld naam is vereist.')
    checkGebruikersnaam(document.getElementById('gebruikersnaam').value);
    checkMail('mail')
    checkwachtwoord('wachtwoord','wachtwoord2')
    checkEmptyField('wachtwoord2','Het veld herhaal wachtwoord is vereist')
    checkEmptyField('adres','Het veld adres is vereist')
    checkEmptyField('land','Het veld land is vereist')
    checkEmptyField('provincie','Het veld provincie is vereist')
    checkPostcode('postcode')
    checkVoorwaarden('');
   
    if (errors.length > 0) {
        let errorList = document.querySelector("#errors ul")
        errorList.innerHTML = "";
        errors.forEach((error) => {
            errorList.innerHTML += `<li>${error}</li>`
        })
        document.querySelector('#success').classList.add('d-none')
        document.querySelector('#info').classList.add('d-none')
        document.querySelector('#errors').classList.remove('d-none')
    } else {
        document.querySelector('#success').classList.remove('d-none')
        document.querySelector('#info').classList.remove('d-none')
        document.querySelector('#errors').classList.add('d-none')
    }
}

function checkEmptyField(id, message) {
    let field = document.querySelector('#' + id)
    if (field && field.value === "") {
        errors.push(message)
    }
}

function hideAlerts() {
    document.querySelector('#success').classList.add('d-none')
    document.querySelector('#errors').classList.add('d-none')
    document.querySelector('#info').classList.add('d-none')
}

function checkwachtwoord(wachtwoordId, wachtwoord2Id) {
let wachtwoord = document.querySelector('#' + wachtwoordId).value;
let wachtwoord2 = document.querySelector('#' + wachtwoord2Id).value;

if (wachtwoord === "") {
errors.push('Het veld wachtwoord is vereist');
} else if (wachtwoord.length < 8) {
errors.push('Wachtwoord moet minstens 8 karakters bevatten');
} else if (wachtwoord !== wachtwoord2) {
errors.push('Wachtwoorden komen niet overeen');
}
}

function checkPostcode(postcode) {
let postcodeField = document.getElementById('postcode');
let postcodeValue = postcodeField.value;

if (postcodeValue === "") {
errors.push("Het veld postcode is vereist.");
} else {
let postcodeNumber = parseInt(postcodeValue);
if (postcodeNumber < 1000 || postcodeNumber > 9999) {
    errors.push("De waarde van postcode moet tussen 1000 en 9999 liggen.");
}
}
}

function checkMail() {
let mailField = document.getElementById('mail');
let mailValue = mailField.value;

if (mailValue === "") {
errors.push('Het veld E-mailadres is vereist');
} else if (!checkEmail(mailValue)) {
errors.push('Geen geldig e-mailadres');
}
}

function checkEmail(mail) {
const Email = /^[a-zA-Z0-9][a-zA-Z0-9._-]*@[a-zA-Z0-9]+\.[a-zA-Z]{2,}$/;


return Email.test(mail);
}

function checkBetaling() {
let keuze = document.querySelector('input[name="flexRadioDefault"]:checked').value;

switch (keuze) {
case 'app':
    keuze = 'banking app';
    break;
case 'overschrijving':
    keuze = 'overschrijving';
    break;
case 'visa':
    keuze = 'visa';
    break;
case 'paypal':
    keuze = 'paypal';
    break;
default:
    break;
}


document.getElementById('keuze').innerText = `Je keuze is: ${keuze}`;
}
function checkVoorwaarden() {
let Checkbox = document.querySelector('#voorwaarden');

if (!Checkbox.checked) {
errors.push('De algemene voorwaarden zijn verplicht');
}
}

function checkGebruikersnaam(gebruikersnaam) {
if (gebruikersnaam.length < 1) {
errors.push('Het veld gebruikersnaam is vereist');
} else if (!/^[a-zA-Z0-9_]+$/.test(gebruikersnaam)) {
errors.push('De gebruikersnaam mag alleen letters, cijfers en underscores bevatten');
} else if (/^[.-]/.test(gebruikersnaam[0])) {
errors.push('De gebruikersnaam mag geen punt of koppelteken als eerste karakter hebben');
}
}